package com.qyp.online

import com.mongodb.casbah.commons.MongoDBObject
import com.mongodb.casbah.{MongoClient, MongoClientURI}
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import redis.clients.jedis.Jedis



//定义一个基准推荐对象
case class Recommendation(jid: Int, score: Double)

//定义基于预测评分的用户推荐列表(最终结果的数据结构)
case class UserRecs(uid: Int, recs: Seq[Recommendation])

//定义基于LFM职位特征向量的职位相似度列表
case class JobRecs(jid: Int, recs: Seq[Recommendation])

case class MongoConfig(uri: String, db: String)

//连接助手对象,序列化操作
object ConnHelper extends Serializable{
  lazy val jedis = new Jedis("localhost")
  lazy val mongoClient = MongoClient(MongoClientURI("mongodb://localhost:27017/JobRecruitment"))
}

object StreamRecommend {

  val MAX_USER_RATINGS_NUM = 20
  val MAX_SIM_JOBS_NUM = 20 //相似的职位数量
  val MONGODB_STREAM_RECS_COLLECTION = "StreamRecs"
  val MONGODB_RATING_COLLECTION = "Rating"
  val MONGODB_JOB_RECS_COLLECTION = "JobRecs"

  def main(args: Array[String]): Unit = {
    val config = Map (
      "spark.cores" -> "local[*]",
      "mongo.uri" -> "mongodb://localhost:27017/JobRecruitment",
      "mongo.db" -> "JobRecruitment",
      "kafka.topic" -> "JobRecruitment"
    )

    val sparkConf = new SparkConf().setMaster(config("spark.cores")).setAppName("StreamRecommend")

    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    //拿到stream context
    val sc = spark.sparkContext
    val ssc = new StreamingContext(sc, Seconds(2)) //Second(2)指的是 批处理时间

    import spark.implicits._

    implicit val mongoConfig = MongoConfig(config("mongo.uri"), config("mongo.db"))

    //加载职位相似度矩阵数据,把它传播出去
    val simJobMatrix = spark.read
      .option("uri", mongoConfig.uri)
      .option("collection", MONGODB_JOB_RECS_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[JobRecs]
      .rdd
      .map { jobRecs => //为了查询相似度更加方便,转换成map; .map()是定义方法 而.map{}是定义操作
        (jobRecs.jid, jobRecs.recs.map(x => (x.jid, x.score)).toMap) //toMap是将Seq转换成map,collectAsMap()将整个结构转换成map
      }.collectAsMap() //装换成为 Map[Int, Map[Int,Double]]

    val simJobMatrixBroadCast = sc.broadcast(simJobMatrix)
    //创建到 Kafka 的连接
    val kafkaParam = Map(
      "bootstrap.servers" -> "192.168.1.103:9092",
      "max.poll.interval.ms" -> "300000",
      "key.deserializer" -> classOf[StringDeserializer], //kafka的key和value序列化
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "JobRecruitment",
      "auto.offset.reset" -> "latest" //偏移量
    )

    //通过kafka创建一个DStream
    val kafkaStream =
      KafkaUtils.createDirectStream[String, String](ssc, LocationStrategies.PreferConsistent, ConsumerStrategies.Subscribe[String, String](Array(config("kafka.topic")), kafkaParam))

    //把原始数据 UID|JID|SCORE|TIMESTAMP 转换成评分流
    val ratingStream = kafkaStream.map { case msg =>
      var attr = msg.value().split("\\|")
      (attr(0).toInt, attr(1).toInt, attr(2).toDouble, attr(3).toInt)
    }

    //继续做流式处理,核心实时算法部分
    ratingStream.foreachRDD {
      //
      rdds =>
        rdds.foreach {
          case (uid, jid, score, timestamp) => {
            println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>rating data coming <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")

            //1.从redis里获取当前用户最近的k次评分,保存成Array[(jid, score)]
            val userRecentlyRatings = getUserRecently(MAX_USER_RATINGS_NUM,uid, ConnHelper.jedis)

            //2.从相似度矩阵中取出当前职位最相似的n个职位,作为备选列表,Array[jid]
            val candidateJobs = getTopSimJobs(MAX_SIM_JOBS_NUM,jid,uid,simJobMatrixBroadCast.value)

            //3.对每个备选职位,计算推荐优先级,得到当前用户的实时推荐列表,Array[(jid, score)]
            val streamRecs = computeJobScores(candidateJobs, userRecentlyRatings,simJobMatrixBroadCast.value)

            //4.把推荐数据保存到,mongodb中
            saveDataToMongoDB(uid, streamRecs)
          }
        }
    }
    //开始接收和处理数据
    ssc.start()

    println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>streaming started!<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
    ssc.awaitTermination() //一直等着

  }

  //redis操作返回的是java类型
  import scala.collection.JavaConversions._ //将java代码转为scala,就可以调用.map()方法
  def getUserRecently(num: Int, uid: Int, jedis: Jedis): Array[(Int, Double)] ={
    //从redis读取数据,用户评分数据保存在 uid:UID 为key的队列里,value是每一个JID:SCORE,相当于某个用户uid, 他的所有评过分的职位JID以及分数获取出来
    jedis.lrange("uid:"+ uid, 0, num-1)
      .map{
        item => //具体每个评分又是以,冒号分隔的两个值
          val attr = item.split("\\:")
          (attr(0).trim.toInt, attr(1).trim.toDouble)
      }
      .toArray  //得到结果直接返回方法
  }

  /**
   * 获取当前职位最相似的num个职位,作为备选职位
   * @param num     相似职位的数量
   * @param jid     当前职位的id
   * @param uid      当前评分用户的id
   * @param simJobs     相似度矩阵
   * @return      过滤之后的备选职位的列表
   */
  def getTopSimJobs(num: Int, jid: Int, uid: Int, simJobs: scala.collection.Map[Int, scala.collection.immutable.Map[Int, Double]])
                     (implicit  mongoConfig: MongoConfig): Array[Int] ={
    //1.从相似度矩阵中拿到所有相似职位,由于map没有排序,所以要转换回Array数据形式
    val allSimJobs = simJobs(jid).toArray

    //2.从mongodb中查询用户已评分的职位
    val ratingExist = ConnHelper.mongoClient(mongoConfig.db)(MONGODB_RATING_COLLECTION)
      .find(MongoDBObject("uid"->uid))//通过uid查找出key为uid的mongo对象
      .toArray
      .map{
        item => item.get("jid").toString().toInt //从对应的mongo对象中取出所有value, value里又是一个map(jid, score),使用get("jid")取出对应的score
      }

    //3.把看过的过滤,得到输出列表
    allSimJobs.filter(x=> !ratingExist.contains(x._1)) //过滤条件为对象中的每一个元素的第一项,即jid,与用户所评分过的职位的jid对比,去掉评分过的
      .sortWith(_._2>_._2)
      .take(num)
      .map(x=>x._1) //只要jid,返回函数
  }

  def computeJobScores(candidateJobs: Array[Int], userRecentlyRatings: Array[(Int, Double)],
                         simJobs: scala.collection.Map[Int, scala.collection.immutable.Map[Int, Double]]): Array[(Int, Double)] ={

    //定义一个ArrayBuffer,用于保存每一个备选职位的基础得分
    val scores = scala.collection.mutable.ArrayBuffer[(Int,Double)]() //创建一个空的对象

    //定义一个计数器HashMap,保存每一个备选电影的增强减弱因子
    val increMap = scala.collection.mutable.HashMap[Int, Int]()
    val decreMap = scala.collection.mutable.HashMap[Int, Int]()

    for (candidateJob <- candidateJobs;userRecentlyRating <-userRecentlyRatings){
      //拿到备选职位和最近评分职位的相似度,就是从备选职位jid和最近评分职位jid求相似度
      val simScore = getMoviesSimScore(candidateJob, userRecentlyRating._1, simJobs)//取两个jid,在相似矩阵中就可以找到它们对应的相似度

      if(simScore > 0.7){
        //计算备选职位的基础推荐得分
        scores += ((candidateJob, simScore * userRecentlyRating._2)) //ArrayBuffer 中的+=() 函数,传入的是一个参数,即最后结果需要转化为一个元祖

        if(userRecentlyRating._2 > 7){ //当前评分若大于7,则增强因子处理
          increMap(candidateJob) = increMap.getOrDefault(candidateJob, 0) + 1 //如果拿不到当前评分,则默认为0
        }else{
          decreMap(candidateJob) = decreMap.getOrDefault(candidateJob, 0) + 1
        }
      }
    }
    //根据备选职位的jid做groupby,根据公式去求最后的推荐评分
    scores.groupBy(_._1).map{
      //groupby 之后得到的数据是Map(jid -> ArrayBuffer[jid, score])
      case (jid, scoreList) =>
        (jid, scoreList.map(_._2).sum / scoreList.length + log(increMap.getOrDefault(jid,1)) -log(decreMap.getOrDefault(jid,1))) //取score 加权平均数求和
    }.toArray
  }

  //获取两个电影之间的相似度
  def getMoviesSimScore(jid1: Int, jid2: Int,  simJobs: scala.collection.Map[Int, scala.collection.immutable.Map[Int, Double]]) : Double ={
    simJobs.get(jid1) match { //case 与 match 主要用来判断, 如果 simJobs.get(jid1)  能找到值,即Some(随意变量) =>变量.执行下一任务, None就是没匹配到的分支
      case Some(sims) => sims.get(jid2) match {
        case Some(score) => score
        case None =>0.0
      }
      case None =>0.0
    }
  }

  //求一个数的对数,底数默认为10
  def log(m: Int) : Double ={
    val  N = 10
    math.log(m) / math.log(N)
  }

  def saveDataToMongoDB(uid: Int, streamRecs: Array[(Int, Double)])(implicit mongoConfig: MongoConfig): Unit ={

    //定义到StreamRecs表的连接
    val streamRecsCollection = ConnHelper.mongoClient(mongoConfig.db)(MONGODB_STREAM_RECS_COLLECTION)

    //如果表中已有uid对应的推荐列表数据,则删除
    streamRecsCollection.findAndRemove(MongoDBObject("uid" -> uid))

    //将streamRecs数据存入表中,结构为   实时推荐(uid,(jid, score))  其中(jid, score)对应streamRecs中的第一二个元素
    streamRecsCollection.insert(MongoDBObject("uid" ->uid, "recs" -> streamRecs.map(x=> MongoDBObject("jid"->x._1, "score" -> x._2))))

  }
}
