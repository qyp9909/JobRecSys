package com.qyp.loader

import com.mongodb.casbah.commons.MongoDBObject
import com.mongodb.casbah.{MongoClient, MongoClientURI}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 1职位id, jid
 * 2公司id，company_id
 * 3企业会员id，company_uid
 * 4招聘类型，recruit_type
 * 6职位名称，job_name
 * 7学历，job_edu
 * 8薪资标准，job_salary
 * 11职位类型，job_type
 * 12职业福利，job_welfare
 * 13工作经验，job_experience
 * 14工作地址，job_address
 * 15工作职责，job_duty
 * 16补充说明，fix_describe
 */
case class Job(jid: Int, company_id: Int, company_uid: Int, job_name: String,
               job_edu: String, job_salary: String,  job_type: String, job_welfare: String, job_experience: String,
               job_address: String,job_duty: String,fix_describe: String, recruit_type: String)

/**\
 *
 * @param uid 用户id
 * @param jid 职位id
 * @param score 满意度评分
 * @param timestamp 评分时间
 */
case class Rating(uid: Int, jid: Int, score: Double, timestamp: Int)

/**
 *
 * @param uid 用户id
 * @param jid 职位id
 * @param tag 标签名（公司类型）
 * @param timestamp 打标签时间
 */
case class Tag(uid: Int, jid: Int, tag: String, timestamp: Int)

/**
 * 吧mongo和es的配置封装成样类
 * @param uri MongoDB的连接
 * @param db  MongoDB数据库
 */
case class MongoConfig(uri: String, db: String)

/**
 *
 * @param httpHosts http主机列表,逗号分隔
 * @param transportHosts transport主机列表.逗号分隔
 * @param index 需要操作的索引
 * @param clustername 集群名称,默认是配置名elasticsearch
 */
case class ESConfig(httpHosts: String, transportHosts: String, index: String, clustername: String)


object JobsDataLoader {

  val JOB_DATA_PATH = "C:\\Users\\Quinn\\Desktop\\学ぶJava_IDEA\\JobRecruitment\\recommendation-part\\DataLoading\\src\\main\\resources\\jobs.csv"
  val RATING_DATA_PATH = "C:\\Users\\Quinn\\Desktop\\学ぶJava_IDEA\\JobRecruitment\\recommendation-part\\DataLoading\\src\\main\\resources\\rating.csv"
  val TAG_DATA_PATH = "C:\\Users\\Quinn\\Desktop\\学ぶJava_IDEA\\JobRecruitment\\recommendation-part\\DataLoading\\src\\main\\resources\\tags.csv"
  val MONGODB_JOB_COLLECTION = "Jobs"
  val MONGODB_RATING_COLLECTION = "Rating"
  val MONGODB_TAG_COLLECTION = "Tag"
  val ES_MOVIE_INDEX = "Job"

  def main(args: Array[String]): Unit = {

    val config = Map(
      "spark.cores" -> "local[*]",
      "mongo.uri" -> "mongodb://localhost:27017/JobRecruitment",
      "mongo.db" -> "JobRecruitment",
      "es.httpHosts" -> "localhost:9200",
      "es.transportHosts" -> "localhost:9300",
      "es.index" -> "JobRecruitment",
      "es.cluster.name" -> "elasticsearch"
    )

    //创建一个sparkConf对象
    val sparkConf = new SparkConf().setMaster(config("spark.cores")).setAppName("DataLoading")

    //创建一个SparkSession
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    // 在对 DataFrame 和 Dataset 进行操作许多操作都需要这个包进行支持
    import spark.implicits._


    //加载数据
    val jobRDD = spark.sparkContext.textFile(JOB_DATA_PATH)


    val jobDF = jobRDD.map(
      item =>{

        val attr = item.split("\\^")//正则表达式转义
        Job(attr(0).toInt, attr(1).toInt, attr(2).toInt, attr(3).trim, attr(4).trim, attr(5).trim, attr(6).trim, attr(7).trim,attr(8).trim,attr(9).trim,
          attr(10).trim, attr(11).trim, attr(12).trim)
      }

    ).toDF()//将RDD转成DataFrame

    val  ratingRDD = spark.sparkContext.textFile(RATING_DATA_PATH)

    val ratingDF = ratingRDD.map(item => {
      val attr = item.split(",")
      Rating(attr(0).toInt,attr(1).toInt,attr(2).toDouble,attr(3).toInt)
    }
    ).toDF()


    val tagRDD = spark.sparkContext.textFile(TAG_DATA_PATH)
    //将 tagRDD 装换为 DataFrame
    val tagDF = tagRDD.map(item => {
      val attr = item.split("\\^")
      Tag(attr(0).toInt,attr(1).toInt,attr(2).trim,attr(3).toInt)
    }).toDF()

    implicit val mongoConfig = MongoConfig(config("mongo.uri"), config("mongo.db"))
    //数据预处理

    //将数据保存到MongoDB
    storeDataInMongoDB(jobDF, ratingDF, tagDF)
//    val newTag = tagDF.groupBy($"jid")
//      .agg(concat_ws("|",collect_set($"tag"))
//        .as("tags"))
//      .select("mid","tags")
//    // 需要将处理后的 Tag 数据，和 Moive 数据融合，产生新的 Movie 数据
//    val movieWithTagsDF = movieDF.join(newTag,Seq("mid","mid"),"left")
//    // 声明了一个 ES 配置的隐式参数
//    implicit val esConfig = ESConfig(config.get("es.httpHosts").get,
//      config.get("es.transportHosts").get,
//      config.get("es.index").get,
//      config.get("es.cluster.name").get)
//    // 需要将新的 Movie 数据保存到 ES 中
//    //将数据保存到ES
//    storeDataInES(movieWithTagsDF)

    spark.stop()

  }

  def storeDataInMongoDB(movieDF: DataFrame, ratingDF: DataFrame, tagDF: DataFrame)(implicit mongoConfig: MongoConfig): Unit ={
    //新建一个mongoDB的连接
    val mongoClient = MongoClient(MongoClientURI(mongoConfig.uri))

    // 如果MongoDB中已经有相应的数据库,先删除
    mongoClient(mongoConfig.db)(MONGODB_JOB_COLLECTION).dropCollection()
    mongoClient(mongoConfig.db)(MONGODB_RATING_COLLECTION).dropCollection()
    mongoClient(mongoConfig.db)(MONGODB_TAG_COLLECTION).dropCollection()

    //将df写入对应的MongoDB表中
    movieDF.write
      .option("uri", mongoConfig.uri)
      .option("collection", MONGODB_JOB_COLLECTION)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    ratingDF
      .write
      .option("uri",mongoConfig.uri)
      .option("collection",MONGODB_RATING_COLLECTION)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()
    tagDF
      .write
      .option("uri",mongoConfig.uri)
      .option("collection",MONGODB_TAG_COLLECTION)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    //对数据表建索引
    mongoClient(mongoConfig.db)(MONGODB_JOB_COLLECTION).createIndex(MongoDBObject("id" -> 1))//类似json key value
    mongoClient(mongoConfig.db)(MONGODB_RATING_COLLECTION).createIndex(MongoDBObject("uid" -> 1))
    mongoClient(mongoConfig.db)(MONGODB_RATING_COLLECTION).createIndex(MongoDBObject("jid" -> 1))
    mongoClient(mongoConfig.db)(MONGODB_TAG_COLLECTION).createIndex(MongoDBObject("uid" -> 1))
    mongoClient(mongoConfig.db)(MONGODB_TAG_COLLECTION).createIndex(MongoDBObject("jid" -> 1))
    //关闭 MongoDB 的连接
    mongoClient.close()
  }

//  def storeDataInES(movieDF:DataFrame)(implicit eSConfig: ESConfig): Unit = {
//    //新建一个配置
//    val settings:Settings = Settings.builder()
//      .put("cluster.name",eSConfig.clustername).build()
//    //新建一个 ES 的客户端
//    val esClient = new PreBuiltTransportClient(settings)
//
//    //需要将 TransportHosts 添加到 esClient 中
//    val REGEX_HOST_PORT = "(.+):(\\d+)".r
//    eSConfig.transportHosts.split(",").foreach{
//      case REGEX_HOST_PORT(host:String,port:String) => {
//        esClient.addTransportAddress(new
//            InetSocketTransportAddress(InetAddress.getByName(host),port.toInt))
//      }
//    }
//    //需要清除掉 ES 中遗留的数据
//    if(esClient.admin().indices().exists(new
//        IndicesExistsRequest(eSConfig.index)).actionGet().isExists){
//      esClient.admin().indices().delete(new DeleteIndexRequest(eSConfig.index))
//    }
//    esClient.admin().indices().create(new CreateIndexRequest(eSConfig.index))
//    //将数据写入到 ES 中
//    movieDF
//      .write
//      .option("es.nodes",eSConfig.httpHosts)
//      .option("es.http.timeout","100m")
//      .option("es.mapping.id","mid") //主键
//      .mode("overwrite")
//      .format("org.elasticsearch.spark.sql")
//      .save(eSConfig.index+"/"+ES_MOVIE_INDEX)
//  }
}
