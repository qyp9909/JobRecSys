package com.qyp.process;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Random;

public class TagData {

    public static void main(String[] args) {


        try {
            BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Quinn\\Desktop\\data1.csv"));//换成你的文件名
            //第一行信息，为标题信息，不用,如果需要，注释掉
            FileWriter writer = new FileWriter("C:\\Users\\Quinn\\Desktop\\tags.csv");
            BufferedWriter bw= new BufferedWriter(writer);
            String line = null;
            int i = 1;
            while((line=reader.readLine())!=null){

                String[] s = line.split("\\^");
                String [] s2 =s[6].split("/");
                if (s2.length!=1){
                    for(String ss : s2){
                        if (ss.length()!=1){
                            ss = String.valueOf(new Random().nextInt(600)+1)+"^"+
                                    String.valueOf(new Random().nextInt(3000)+1)+"^"+
                                    ss+"^"+String.valueOf(System.currentTimeMillis()/1000-(new Random().nextInt(10000)+1));
                                    bw.write(ss);
                                    bw.newLine();
                                    System.out.println(ss);
                        }
                    }
                }
            }
            bw.close();
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
