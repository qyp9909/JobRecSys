package com.qyp.process;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Random;

public class JobData {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Quinn\\Desktop\\datamining.csv"));//换成你的文件名
            //第一行信息，为标题信息，不用,如果需要，注释掉
            FileWriter writer = new FileWriter("C:\\Users\\Quinn\\Desktop\\data1.csv");
            BufferedWriter bw= new BufferedWriter(writer);
            System.out.println(reader.readLine());
            String line = null;
            int i = 1;
            while((line=reader.readLine())!=null){

                String line1=line.replaceAll("\"", "");
                String line2=line1.replaceAll(",\\^", "^");//jid,company_id,company_uid

                Random r = new Random();
                String type ="";
                if (r.nextInt(2)+1 ==1){
                        type ="校招";
                }else {
                    type="社招";
                }
                String line3 = String.valueOf(i)+"^"+String.valueOf(i+System.currentTimeMillis()/1000000)
                        +"^"+String.valueOf(i+System.currentTimeMillis()/1000000) +line2+"^"+type;

                System.out.println(line3);

                bw.write(line3);
                bw.newLine();
                i++;

            }
            bw.close();
            writer.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
