package com.qyp.process;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class RatingData {

    public static void main(String[] args) throws IOException {

        StringBuffer line=new StringBuffer();

        for (int i = 0; i<600;i++){//选取600个随机的用户，打分
           Random r=  new Random();
           int uid =  r.nextInt(600)+1;
           for (int j = 0; j<new Random().nextInt(60)+30;j++){
               line.append(String.valueOf(uid)+","
                       +String.valueOf(new Random().nextInt(3000)+1)+","
                       +String.valueOf(new Random().nextInt(10)+1)+","
                       +String.valueOf(System.currentTimeMillis()/1000-(new Random().nextInt(10000)+1))+"\r\n");
           }

        }

        System.out.println(line.toString());

        FileWriter writer = new FileWriter("C:\\Users\\Quinn\\Desktop\\rating.csv");
        writer.write(String.valueOf(line));
        writer.close();

    }
}
