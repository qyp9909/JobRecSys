package com.qyp.statistic

import java.text.SimpleDateFormat
import java.util.Date

import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}


case class Job(jid: Int, company_id: Int, company_uid: Int, job_name: String,
               job_edu: String, job_salary: String,  job_type: String, job_welfare: String, job_experience: String,
               job_address: String,job_duty: String,fix_describe: String, recruit_type: String)

case class Rating(uid: Int, jid: Int, score: Double, timestamp: Int)


case class Tag(uid: Int, jid: Int, tag: String, timestamp: Int)

case class MongoConfig(uri: String, db: String)

//定义一个基准推荐对象
case class Recommendation(jid: Int, score: Double)

//定义电影类别top10推荐对象
case class GenresRecommendation(job_type: String, recs: Seq[Recommendation])

object StatisticRecommend{

  //定义表名
  val MONGODB_RATING_COLLECTION = "Rating"
  val MONGODB_JOB_COLLECTION = "Jobs"
  //统计的表的名称
  val MOST_RATING_JOBS= "MostRatingJobs" //最多评分
  val MOST_RECENTLY_RATING = "MostRecentlyRating"//最近评分
  val AVERAGE_RATING = "AverageRating"//平均评分
  val GENRES_TOP_MOVIES = "GenresTopMovies"//top评分


  def main(args: Array[String]): Unit = {
    val config = Map(
      "spark.cores" -> "local[*]",
      "mongo.uri" -> "mongodb://localhost:27017/JobRecruitment",
      "mongo.db" -> "JobRecruitment"
    )
    //创建一个sparkConf对象
    val sparkConf = new
        SparkConf().setAppName("StatisticsRecommend").setMaster(config("spark.cores"))

    //创建一个SparkSession
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    // 在对 DataFrame 和 Dataset 进行操作许多操作都需要这个包进行支持
    implicit val mongoConfig = MongoConfig(config("mongo.uri"), config("mongo.db"))

    import spark.implicits._

    //从mongo里加载数据
    val ratingDF = spark.read
      .option("uri", mongoConfig.uri)
      .option("collection",MONGODB_RATING_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[Rating]
      .toDF()

    val jobDF =  spark.read
      .option("uri", mongoConfig.uri)
      .option("collection",MONGODB_JOB_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[Job]
      .toDF()

    //创建名为ratings的临时表
    ratingDF.createOrReplaceTempView("ratings")

    //TODO: 不同的统计推荐结果
    //1.历史热门统计,历史评分数据最多, 数据筛选出来jid, count,  sparksql默认返回Dataframe类型
    val rateMoreMoviesDF = spark.sql("select jid, count(jid) as count from ratings group by jid")
    //把结果写入对应的mongodb表中
    storeDFInMongoDB(rateMoreMoviesDF, MOST_RATING_JOBS)

    //2.近期热门统计, 按照yyyyMM格式选取最近的评分数据,统计评分个数
    //创建一个日期格式化工具,主要是给的数据里的时间是秒数
    val simpleDateFormat = new SimpleDateFormat("yyyyMM")
    //注册udf,把时间戳转换成年月格式,必须用long类型因为int 范围是+-20亿之间
    spark.udf.register("changeDate",(x:Int)=>simpleDateFormat.format(new Date(x*1000L)).toInt )

    //对原始数据进行预处理,去掉uid
    val ratingOfYearMonth = spark.sql("select jid, score, changeDate(timestamp) as yearmonth from ratings")
    ratingOfYearMonth.createOrReplaceTempView("ratingOfMonth")

    //从ratingOfMonth中查找电影在各个月份的评分, mid ,count, yearmonth
    val rateMoreRecentlyMoviesDF = spark.sql("select jid, count(jid) as count, yearmonth from ratingOfMonth group by yearmonth, jid order by yearmonth desc, count desc")

    //存入mongodb
    storeDFInMongoDB(rateMoreRecentlyMoviesDF, MOST_RECENTLY_RATING)

    //3.优质职位统计,统计职位的平均评分, jid, avg
    val averageMoviesDF = spark.sql("select jid ,avg(score) as avg from ratings group by jid")
    storeDFInMongoDB(averageMoviesDF, AVERAGE_RATING)

    //4.各类别电影top统计
    // 定义所有类别
//    val genres =
//    List("Action","Adventure","Animation","Comedy","Crime","Documentary","Drama","Family","Fantasy","Foreign","History","Horror","Music","Mystery"
//      ,"Romance","Science","Tv","Thriller","War","Western")
//
//    //把平均评分加入movie表里,相当于加一列 ;inner join,选出来的必须是既有电影内容信息又有平均评分的
//    val movieWithScore = movieDF.join(averageMoviesDF, "mid")//直接写join默认inner join ,给的字段就是join的字段
//
//    //为了做笛卡尔积,把genres转成rdd
//    val genresRDD = spark.sparkContext.makeRDD(genres)
//
//    //计算类别top10,首先对类别和电影做笛卡尔积
//    val genresTopMoviesDF = genresRDD.cartesian(movieWithScore.rdd)
//      .filter{
//        //需要找出本身movie里有一个genres的字段,且是用 '|'分隔的类别, 我们要找出其中包含了当前类别的那些
//        //条件过滤,需要条件判断
//        case(genres ,row) =>row.getAs[String]("genres").toLowerCase.contains(genres.toLowerCase)
//      }
//      .map{//--------------->一个类别一个元祖(mid, avg)
//        case (genres, row) =>(genres, (row.getAs[Int]("mid"), row.getAs[Double]("avg")))
//      }
//      .groupByKey()
//      .map{
//        case (genre, items) =>GenresRecommendation(genre, items.toList.sortWith(_._2>_._2).take(10).map(items=>Recommendation(items._1, items._2)
//        ))
//      }
//      .toDF()
//    storeDFInMongoDB(genresTopMoviesDF,GENRES_TOP_MOVIES)

    spark.stop()
  }


  def storeDFInMongoDB(df: DataFrame, collection_name: String)(implicit mongoConfig: MongoConfig): Unit ={
    df.write
      .option("uri", mongoConfig.uri)
      .option("collection", collection_name)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()
  }
}
