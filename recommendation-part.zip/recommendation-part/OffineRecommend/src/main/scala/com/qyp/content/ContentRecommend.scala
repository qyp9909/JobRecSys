package com.qyp.content

import org.apache.spark.SparkConf
import org.apache.spark.ml.feature.{HashingTF, IDF, Tokenizer}
import org.apache.spark.ml.linalg.SparseVector
import org.apache.spark.sql.SparkSession
import org.jblas.DoubleMatrix


//需要的数据源是职位内容信息
case class Job(jid: Int, company_id: Int, company_uid: Int, job_name: String,
               job_edu: String, job_salary: String,  job_type: String, job_welfare: String, job_experience: String,
               job_address: String,job_duty: String,fix_describe: String, recruit_type: String)

//定义一个基准推荐对象
case class Recommendation(jid: Int, score: Double)

//定义基于预测评分的用户推荐列表(最终结果的数据结构)
case class UserRecs(uid: Int, recs: Seq[Recommendation])

//定义基于LFM职位特征向量的特征相似度列表
case class JobRecs(jid: Int, recs: Seq[Recommendation])

case class MongoConfig(uri: String, db: String)

object ContentRecommend {

  //定义表名
  val MONGODB_JOB_COLLECTION = "Jobs"
  val CONTENT_JOB_RECS = "ContentJobRecs"

  def main(args: Array[String]): Unit = {
    val config = Map(
      "spark.cores" -> "local[*]",
      "mongo.uri" -> "mongodb://localhost:27017/JobRecruitment",
      "mongo.db" -> "JobRecruitment"
    )

    val sparkConf = new SparkConf().setMaster(config("spark.cores")).setAppName("ContentRecommend")

    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    implicit val mongoConfig = MongoConfig(config("mongo.uri"),config("mongo.db"))

    import spark.implicits._

    //加载数据并做预处理
    val jobTagsDF = spark.read
      .option("uri",mongoConfig.uri)
      .option("collection",MONGODB_JOB_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[Job]
      .map(x => (x.jid, x.job_name, x.job_type.map(c=> if(c=='/') ' ' else c))) //将分隔符/转化为空格分开,分词器一共提取jid，job_name，job_type三项作为原始内容特征
      .toDF("jid","job_name","job_type")
      .cache()



    //TODO: 从内容信息中提取职位特征向量

    //创建一个分词器，默认按空格分词，输入一列后输出一列结果，输入为job_type，输出为words
    val tokenizer = new Tokenizer().setInputCol("job_type").setOutputCol("words")

    //用分词器对原始数据做转换，生成新的一列words
    val wordsData = tokenizer.transform(jobTagsDF)

    val hashingTF = new HashingTF().setInputCol("words").setOutputCol("rawFeatures").setNumFeatures(50)
    val fData = hashingTF.transform(wordsData)

    val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
    //训练IDF模型，得到每一个词的逆文档频率
    val idfModel = idf.fit(fData)
    //用模型对元数据进行处理，得到文档中每个词的tf-idf作为新的特征向量
    val rescaledData = idfModel.transform(fData)
    rescaledData.show()

    val jobFeatures = rescaledData.map(
      row => (row.getAs[Int]("jid"),row.getAs[SparseVector]("features").toArray)
    )
      .rdd
      .map(
        x => (x._1, new  DoubleMatrix(x._2))
      )

    jobFeatures.collect().foreach(println)

    //对所有职位两两计算它们的相似度,先做笛卡尔积
    val jobRecs = jobFeatures.cartesian(jobFeatures)
      .filter{//把自己跟自己配对过滤掉,即不能推荐自己
        case (a,b) =>a._1 != b._1
      }
      .map{
        case (a, b) =>{
          val simScore = this.consinSim(a._2, b._2)
          (a._1,(b._1, simScore))//放在最后一行为返回
        }
      }
      .filter(_._2._2 > 0.6) //过滤出相似度大于0.6的项
      .groupByKey()
      .map{
        case (mid, items) =>JobRecs(mid, items.toList.sortWith(_._2>_._2).map(x=>Recommendation(x._1,x._2)))
      }
      .toDF()

    //存入MongoDB
    jobRecs.write
      .option("uri",mongoConfig.uri)
      .option("collection",CONTENT_JOB_RECS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    spark.stop()
  }
  //求向量余弦相似度
  def consinSim(job1: DoubleMatrix, job2: DoubleMatrix):Double ={
    job1.dot(job2) / ( job1.norm2() * job2.norm2() )//分子点乘除分母模长

  }


}
