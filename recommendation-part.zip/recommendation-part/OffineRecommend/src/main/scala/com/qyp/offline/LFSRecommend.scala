package com.qyp.offline

import org.apache.spark.SparkConf
import org.apache.spark.mllib.recommendation.{ALS, Rating}
import org.apache.spark.sql.SparkSession
import org.jblas.DoubleMatrix

//基于评分数据的LFM,只需要引入评分数据,由于spark的mllib里有Rating这个类,因此需要改名
case class JobRating(uid: Int, jid: Int, score: Double, timestamp: Int)

//定义一个基准推荐对象
case class Recommendation(jid: Int, score: Double)

//定义基于预测评分的用户推荐列表(最终结果的数据结构)
case class UserRecs(uid: Int, recs: Seq[Recommendation])

//定义基于LFM职位特征向量的特征相似度列表
case class JobRecs(jid: Int, recs: Seq[Recommendation])

case class MongoConfig(uri: String, db: String)

object LFSRecommend{

  //定义表名
  val MONGODB_RATING_COLLECTION = "Rating"
  val USER_RECS = "UserRecs"
  val JOB_RECS = "JobRecs"
  val USER_MAX_RECOMMENDATION = 20

  def main(args: Array[String]): Unit = {
    val config = Map(
      "spark.cores" -> "local[*]",
      "mongo.uri" -> "mongodb://localhost:27017/JobRecruitment",
      "mongo.db" -> "JobRecruitment"
    )
    val sparkConf = new SparkConf().setMaster(config("spark.cores")).setAppName("LFSRecommend")

    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    import spark.implicits._

    implicit val mongoConfig = MongoConfig(config("mongo.uri"),config("mongo.db"))

    //加载数据
    val ratingRDD = spark.read
      .option("uri", mongoConfig.uri)
      .option("collection",MONGODB_RATING_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[JobRating]
      .rdd
      .map(rating => (rating.uid, rating.jid, rating.score))// 使用map可以变成自己想要的数据状态,进行数据清洗;转换成rdd,并且去掉时间戳
      .cache()//持久化在内存里

    //从rating数据中提取所有的uid和jid,并且去重
    val userRDD = ratingRDD.map(_._1).distinct() //_._1是从ratingRDD中取出第一项,上面有ratingRDD.map(rating => (rating.uid, rating.jid, rating.score)),因此第一项是uid
    val jobRDD = ratingRDD.map(_._2).distinct()

    //训练隐语义模型
    val trainData = ratingRDD.map(x=> Rating(x._1, x._2, x._3))
    // rank 是模型中隐语义因子的个数, iterations 是迭代的次数, lambda 是 ALS 的正则化参
    val (rank,iterations,lambda) = (250, 5, 1)
    // 调用 ALS 算法训练隐语义模型
    val model = ALS.train(trainData,rank,iterations,lambda)

    //基于用户和职位的隐特征,计算和预测评分,根据评分高低得到用户推荐列表
    //计算user和job的笛卡尔积,得到一个空评分矩阵
    val userMovies = userRDD.cartesian(jobRDD)
    //调用model的predict方法预测评分
    val preRatings = model.predict(userMovies)
    val userRecs = preRatings
      .filter(_.rating>0) //过滤出评分大于0的项
      .map(rating => (rating.user, (rating.product, rating.rating)))
      .groupByKey()//按照key分组聚合
      .map{
        case (uid, recs) => UserRecs(uid,recs.toList.sortWith(_._2>_._2).take(USER_MAX_RECOMMENDATION).map(x=>Recommendation(x._1, x._2)))
      }//sortWith(_._2>_._2)按照第二个元素降序排列,take20即为取前二十个, 后面的.map(x=>Recommendation(x._1, x._2)))就是将20个结果每一个元素作为x,取出其中第一二项转入Recommendation里
      .toDF()

    //存入MongoDB
    userRecs.write
      .option("uri",mongoConfig.uri)
      .option("collection",USER_RECS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    //基于职位隐特征计算职位相似度矩阵,得到职位的相似度列表
    val jobFeatures = model.productFeatures.map{//模式匹配
      case (jid, features) => (jid, new DoubleMatrix(features))
    }

    //对所有职位两两计算它们的相似度,先做笛卡尔积
    val jobRecs = jobFeatures.cartesian(jobFeatures)
      .filter{//把自己跟自己配对过滤掉,即不能推荐自己
        case (a,b) =>a._1 != b._1
      }
      .map{
        case (a, b) =>{
          val simScore = this.consinSim(a._2, b._2)
          (a._1,(b._1, simScore))//放在最后一行为返回
        }
      }
      .filter(_._2._2 > 0.6) //过滤出相似度大于0.6的项
      .groupByKey()
      .map{
        case (jid, items) =>JobRecs(jid, items.toList.sortWith(_._2>_._2).map(x=>Recommendation(x._1,x._2)))
      }
      .toDF()

    //存入MongoDB
    jobRecs.write
      .option("uri",mongoConfig.uri)
      .option("collection",JOB_RECS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    spark.stop()
  }

  //求向量余弦相似度
  def consinSim(job1: DoubleMatrix, job2: DoubleMatrix):Double ={
    job1.dot(job2) / ( job1.norm2() * job2.norm2() )//分子点乘除分母模长

  }

}
